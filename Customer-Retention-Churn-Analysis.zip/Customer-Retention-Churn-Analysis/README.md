# Customer Retention & Churn Analysis (Task 2 - 2026)

A Streamlit dashboard to analyze churn/retention using cohort retention, churn-rate trends, and tenure distribution.

## Features
- Upload a CSV dataset (optional)
- Auto-detect likely columns:
  - `customer_id`
  - `signup/start date`
  - `event/end date` (last active / churn date)
  - `churn flag`
  - optional segmentation columns (plan/region/etc.)
- Cohort retention: retention by signup month across months since signup
- Churn rate over time (by event month)
- Business-focused insights text blocks
- Built-in synthetic dataset fallback (so the app runs immediately)

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Run
```bash
streamlit run app.py
```

Then open the local URL shown in the terminal (typically http://localhost:8501).

## Dataset expectations
Your CSV should contain one row per customer (or per customer lifecycle) with at least:
- A customer identifier column (e.g., `customer_id`, `user_id`, `subscriber_id`)
- A signup/start date column (e.g., `signup_date`, `start_date`, `created_at`)
- A churn/end/last-active date column (e.g., `churn_date`, `last_active_date`, `subscription_end`)
- A churn flag column (optional but recommended): values like `0/1`, `true/false`, `yes/no`.

Column names do not need to match exactly; the app uses fuzzy detection based on keywords.

## Notes
- If churn flag or event date is missing, the dashboard will still try to run, but some metrics may be limited.

