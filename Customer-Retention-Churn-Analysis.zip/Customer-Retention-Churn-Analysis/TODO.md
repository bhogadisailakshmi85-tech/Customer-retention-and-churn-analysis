# TODO - Customer Retention & Churn Analysis (Task 2 - 2026)

- [x] Inspect existing `churn_analysis.ipynb` (currently not readable via tool; may need alternative approach).
- [x] Create a Streamlit-based retention dashboard/project from scratch (using the included `requirements.txt`).
- [x] Add data loading + cleaning pipeline (works with a user-provided dataset or sample synthetic data).
- [ ] Implement churn/retention metrics:
  - [x] Churn rate & retention rate over time
  - [x] Cohort retention (by signup month)
  - [x] Customer lifetime (survival/tenure distribution)
  - [x] Segment breakdown (plan/region, if present)
- [ ] Add retention drivers / churn reasons analysis (feature importance via baseline ML if dataset has labels).
- [x] Provide business-focused insights text blocks.
- [x] Add README with setup + usage instructions.
- [ ] Run a quick local validation (start Streamlit) and ensure dashboard renders.


