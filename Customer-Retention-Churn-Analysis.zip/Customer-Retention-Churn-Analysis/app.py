import io
import re
from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st


st.set_page_config(page_title="Customer Retention & Churn Analysis", layout="wide")


@dataclass
class Cols:
    customer_id: str
    signup_date: Optional[str]
    event_date: Optional[str]
    churn_flag: Optional[str]
    segment_cols: Tuple[str, ...]


def _normalize_cols(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [re.sub(r"\s+", " ", str(c)).strip().lower().replace("/", "_") for c in df.columns]
    return df


def _find_column(df: pd.DataFrame, candidates) -> Optional[str]:
    cols = list(df.columns)
    for cand in candidates:
        cand_l = cand.lower()
        # exact match
        if cand_l in cols:
            return cand_l
    # fuzzy contains
    for cand in candidates:
        cand_l = cand.lower()
        for c in cols:
            if cand_l == c:
                return c
            if cand_l in c:
                return c
    return None


def detect_columns(df: pd.DataFrame) -> Cols:
    df_n = _normalize_cols(df)

    customer_id = _find_column(
        df_n,
        [
            "customer_id",
            "customer id",
            "customerid",
            "user_id",
            "user id",
            "subscriber_id",
            "subscriber id",
            "id",
        ],
    )

    signup_date = _find_column(
        df_n,
        ["signup_date", "signup date", "start_date", "start date", "registration_date", "created_at", "join_date", "joined_at"],
    )

    event_date = _find_column(
        df_n,
        [
            "churn_date",
            "churn date",
            "last_active_date",
            "last active date",
            "last_seen",
            "last_seen_date",
            "last login",
            "event_date",
            "activity_date",
            "subscription_end",
            "end_date",
            "period_end",
        ],
    )

    churn_flag = _find_column(df_n, ["churn", "churn_flag", "is_churn", "churned", "target", "label", "status"])

    # if we have a churn flag, avoid using status if it looks like text
    segment_cols = []
    for c in df_n.columns:
        if c in {customer_id, signup_date, event_date, churn_flag}:
            continue
        if any(k in c for k in ["plan", "region", "country", "age", "gender", "segment", "tenure", "tier", "industry"]):
            segment_cols.append(c)

    segment_cols = tuple(list(dict.fromkeys(segment_cols))[:3])

    if customer_id is None:
        # fallback to first column
        customer_id = df_n.columns[0]

    return Cols(
        customer_id=customer_id,
        signup_date=signup_date,
        event_date=event_date,
        churn_flag=churn_flag,
        segment_cols=segment_cols,
    )


def coerce_datetime(series: pd.Series) -> pd.Series:
    if series.dtype.kind in {"M"}:
        return series
    return pd.to_datetime(series, errors="coerce", utc=False)


def coerce_churn_flag(series: pd.Series) -> pd.Series:
    s = series
    if s.dtype == bool:
        return s.astype(int)

    if s.dtype.kind in {"i", "u"}:
        return (s > 0).astype(int)

    s_l = s.astype(str).str.strip().str.lower()
    # common mappings
    mapping = {
        "yes": 1,
        "y": 1,
        "true": 1,
        "t": 1,
        "1": 1,
        "churn": 1,
        "churned": 1,
        "active": 0,
        "no": 0,
        "n": 0,
        "false": 0,
        "f": 0,
        "0": 0,
    }
    return s_l.map(mapping).fillna(0).astype(int)


def build_synthetic_dataset(n_customers: int = 2000, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    customer_id = np.arange(1, n_customers + 1)
    signup_start = pd.Timestamp("2024-01-01")
    signup_days = rng.integers(0, 180, size=n_customers)
    signup_date = signup_start + pd.to_timedelta(signup_days, unit="D")

    plan = rng.choice(["Basic", "Pro", "Enterprise"], size=n_customers, p=[0.55, 0.35, 0.10])
    region = rng.choice(["NA", "EU", "APAC"], size=n_customers, p=[0.45, 0.35, 0.20])

    # hazard depends on plan/region
    plan_factor = np.where(plan == "Basic", 1.25, np.where(plan == "Pro", 0.95, 0.75))
    region_factor = np.where(region == "NA", 1.05, np.where(region == "EU", 0.95, 0.90))

    # sample churn time via exponential-ish model
    base_monthly_hazard = 0.055
    monthly_hazard = np.clip(base_monthly_hazard * plan_factor * region_factor, 0.01, 0.25)

    # simulate churn over 18 months
    max_months = 18
    churn = np.zeros(n_customers, dtype=int)
    churn_month = np.full(n_customers, np.nan)

    for i in range(n_customers):
        # iterate months
        p_churn_each = monthly_hazard[i]
        for m in range(max_months):
            if rng.random() < p_churn_each:
                churn[i] = 1
                churn_month[i] = m
                break

    # compute event_date: churn date for churned else last_active_date (censored)
    event_date = []
    for i in range(n_customers):
        if churn[i] == 1:
            event_date.append(signup_date[i] + pd.to_timedelta(int(churn_month[i] * 30) + rng.integers(0, 20), unit="D"))
        else:
            # active to end window
            event_date.append(signup_date[i] + pd.to_timedelta(rng.integers(360, 540), unit="D"))

    last_active_date = pd.to_datetime(event_date)

    df = pd.DataFrame(
        {
            "customer_id": customer_id.astype(str),
            "signup_date": pd.to_datetime(signup_date),
            "last_active_date": last_active_date,
            "churn": churn,
            "plan": plan,
            "region": region,
        }
    )

    return df


def prepare_retention_table(df: pd.DataFrame, cols: Cols) -> Tuple[pd.DataFrame, pd.DataFrame]:
    dfn = _normalize_cols(df)

    # ensure date fields
    signup_col = cols.signup_date
    event_col = cols.event_date
    churn_col = cols.churn_flag

    if signup_col is None:
        # fabricate signup at earliest date-like column
        date_candidates = [c for c in dfn.columns if "date" in c or "created" in c or "signup" in c or "join" in c or "start" in c]
        if date_candidates:
            signup_col = date_candidates[0]
        else:
            raise ValueError("Could not detect a signup/start date column. Please upload data with a signup/start date.")

    if event_col is None:
        # use last active date if churn date absent
        event_candidates = [
            c
            for c in dfn.columns
            if any(k in c for k in ["last_active", "last active", "last_seen", "end", "churn_date", "churn date", "period_end", "active_until"])
        ]
        if event_candidates:
            event_col = event_candidates[0]
        else:
            # if churn flag exists, set event date equal to signup + synthetic tenure
            event_col = None

    dfn[cols.customer_id] = dfn[cols.customer_id].astype(str)
    dfn[signup_col] = coerce_datetime(dfn[signup_col])

    if event_col is not None:
        dfn[event_col] = coerce_datetime(dfn[event_col])
    else:
        # censored: assume activity until end
        dfn["__event_date_synth"] = dfn[signup_col] + pd.to_timedelta(150 + np.random.randint(0, 90, size=len(dfn)), unit="D")
        event_col = "__event_date_synth"

    # churn flag
    if churn_col is None:
        # infer churn from whether event_date exists in a churn-date column (not possible)
        dfn["__churn_synth"] = 0
        churn_col = "__churn_synth"
    else:
        dfn[churn_col] = coerce_churn_flag(dfn[churn_col])

    # drop rows without signup
    dfn = dfn.dropna(subset=[signup_col]).copy()

    dfn["signup_month"] = dfn[signup_col].dt.to_period("M").dt.to_timestamp()
    dfn["event_month"] = dfn[event_col].dt.to_period("M").dt.to_timestamp()

    # tenure in months (approx)
    dfn["tenure_months"] = ((dfn[event_col] - dfn[signup_col]).dt.days / 30.437).clip(lower=0)

    # cohort month index: months since signup to event month
    dfn["months_since_signup"] = ((dfn[event_col].dt.to_period("M") - dfn[signup_col].dt.to_period("M")).apply(lambda x: x.n)).astype(int)
    dfn = dfn[(dfn["months_since_signup"] >= 0) & (dfn["months_since_signup"] <= 60)].copy()

    # cohort retention: for each signup_month and k, share not churned by month k
    # If churn=1, consider churn month as event month; non-churn are censored at event month.
    cohort = dfn.groupby(["signup_month"]) .size().rename("cohort_size").reset_index()

    # For each row, determine churn month index; for churned=1, treat that row as churn at its months_since_signup.
    # retention at k = 1 - (#churned with months_since_signup <= k) / cohort_size
    max_k = int(dfn["months_since_signup"].max())
    k_vals = list(range(0, min(24, max_k + 1)))

    churn_counts = (
        dfn[dfn[churn_col] == 1]
        .groupby(["signup_month", "months_since_signup"]) 
        .size()
        .rename("churned")
        .reset_index()
    )

    out_rows = []
    for _, row in cohort.iterrows():
        sm = row["signup_month"]
        size = row["cohort_size"]
        subset = churn_counts[churn_counts["signup_month"] == sm]
        churn_by_k = []
        for k in k_vals:
            c = subset[subset["months_since_signup"] <= k]["churned"].sum() if not subset.empty else 0
            retention = 1 - (c / size if size else 0)
            out_rows.append((sm, k, retention, c))

    retention_df = pd.DataFrame(out_rows, columns=["signup_month", "month_index", "retention_rate", "churned_by_or_before"])

    # overall trends (event_month churn rate)
    event_roll = dfn.groupby("event_month").agg(
        customers=(cols.customer_id, "nunique"),
        churned=(churn_col, "sum"),
    ).reset_index()
    event_roll["churn_rate"] = event_roll["churned"] / event_roll["customers"].replace({0: np.nan})
    event_roll = event_roll.sort_values("event_month")

    return retention_df, event_roll


def main():
    st.title("Customer Retention & Churn Analysis (Task 2 - 2026)")
    st.caption("Upload your churn/retention dataset (CSV) or use the built-in synthetic dataset.")

    with st.sidebar:
        st.header("Dataset")
        uploaded = st.file_uploader("Upload CSV", type=["csv"])
        use_synthetic = st.button("Use synthetic dataset")

        st.divider()
        st.header("Settings")
        sample_rows = st.slider("Sample rows (for speed)", min_value=500, max_value=20000, value=5000, step=500)

    if uploaded is not None:
        df = pd.read_csv(uploaded)
    elif use_synthetic or uploaded is None:
        df = build_synthetic_dataset()
    else:
        df = build_synthetic_dataset()

    if len(df) > sample_rows:
        df = df.sample(sample_rows, random_state=42)

    cols = detect_columns(df)
    st.subheader("Detected columns")
    st.write(
        {
            "customer_id": cols.customer_id,
            "signup_date": cols.signup_date,
            "event_date (churn/last active/end)": cols.event_date,
            "churn_flag": cols.churn_flag,
            "segment_cols": cols.segment_cols,
        }
    )

    try:
        retention_df, event_roll = prepare_retention_table(df, cols)
    except Exception as e:
        st.error(f"Failed to compute metrics: {e}")
        st.stop()

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Churn rate over time")
        fig = px.line(event_roll, x="event_month", y="churn_rate", markers=True, title="Churn rate by event month")
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.subheader("Tenure distribution (months)")
        dfn = _normalize_cols(df)
        # best-effort tenure
        signup_col = cols.signup_date
        event_col = cols.event_date
        if signup_col is None:
            st.warning("signup date not detected; tenure distribution may be limited")
            tenure = None
        else:
            dfn[signup_col] = coerce_datetime(dfn[signup_col])
            if event_col is not None and event_col in dfn.columns:
                dfn[event_col] = coerce_datetime(dfn[event_col])
                tenure = ((dfn[event_col] - dfn[signup_col]).dt.days / 30.437).clip(lower=0)
            else:
                tenure = None

        if tenure is not None:
            hist = px.histogram(x=tenure, nbins=40, title="Customer tenure (months)")
            st.plotly_chart(hist, use_container_width=True)
        else:
            st.info("Tenure distribution requires an end/last-active/churn date column.")

    st.divider()
    st.subheader("Cohort retention (signup month vs. months since signup)")

    # show the most recent cohorts
    cohorts_sorted = retention_df["signup_month"].drop_duplicates().sort_values()
    last_cohorts = cohorts_sorted.tail(6)
    plot_df = retention_df[retention_df["signup_month"].isin(last_cohorts)].copy()
    fig2 = px.line(plot_df, x="month_index", y="retention_rate", color="signup_month", markers=True)
    fig2.update_layout(xaxis_title="Month index since signup", yaxis_title="Retention rate", legend_title="Signup month")
    st.plotly_chart(fig2, use_container_width=True)

    # business insights
    st.divider()
    st.subheader("Business insights (what to do next)")

    # derive a couple indicators
    overall_curve = retention_df.groupby("month_index")["retention_rate"].mean().reset_index()


    m3 = float(overall_curve[overall_curve["month_index"] == 3]["retention_rate"].iloc[0]) if 3 in overall_curve["month_index"].values else None
    m6 = float(overall_curve[overall_curve["month_index"] == 6]["retention_rate"].iloc[0]) if 6 in overall_curve["month_index"].values else None

    insights = []
    if m3 is not None:
        insights.append(f"Avg retention at Month 3 is **{m3:.1%}**. If this is low, focus on onboarding + early value delivery (first 30–60 days).")
    if m6 is not None:
        insights.append(f"Avg retention at Month 6 is **{m6:.1%}**. For churn around this point, review product adoption, feature usage, and support/renewal touchpoints.")

    if len(cols.segment_cols) > 0:
        # simple segmentation view for retention at month 3 or max available
        seg = cols.segment_cols[0]
        signup_col = cols.signup_date
        if signup_col is not None:
            dfn = _normalize_cols(df)
            dfn[signup_col] = coerce_datetime(dfn[signup_col])
            dfn["signup_month"] = dfn[signup_col].dt.to_period("M").dt.to_timestamp()
            churn_col = cols.churn_flag if cols.churn_flag in dfn.columns else None
            event_col = cols.event_date
            if churn_col is not None and event_col is not None:
                dfn[event_col] = coerce_datetime(dfn[event_col])
                dfn["months_since_signup"] = ((dfn[event_col].dt.to_period("M") - dfn[signup_col].dt.to_period("M")).apply(lambda x: x.n)).astype(int)
                # retention at k = not churned by k
                k = 3 if retention_df["month_index"].max() >= 3 else int(retention_df["month_index"].max())
                seg_stats = []
                for val, g in dfn.groupby(seg):
                    size = g[cols.customer_id].nunique()
                    churned = g[(coerce_churn_flag(g[churn_col]) == 1) & (g["months_since_signup"] <= k)][cols.customer_id].nunique()
                    retention = 1 - (churned / size if size else 0)
                    seg_stats.append((val, retention, size))
                seg_stats = sorted(seg_stats, key=lambda x: x[1], reverse=True)[:10]
                best = seg_stats[0]
                worst = seg_stats[-1]
                insights.append(
                    f"Top retention segment by {seg}: **{best[0]}** ({best[1]:.1%}). Lowest: **{worst[0]}** ({worst[1]:.1%}). Use this to tailor onboarding + winback campaigns."
                )

    if not insights:
        insights.append("Use the cohort retention chart to identify where retention drops fastest, then connect that point to product adoption milestones (e.g., activation, feature usage, successful first outcome).")

    for i in insights:
        st.markdown(f"- {i}")


if __name__ == "__main__":
    main()
